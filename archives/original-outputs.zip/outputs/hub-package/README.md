---
license: apache-2.0
library_name: stable-baselines3
tags:
- reinforcement-learning
- PPO
- LunarLander-v3
model-index:
- name: PPO LunarLander-v3
  results:
  - task:
      type: reinforcement-learning
      name: Reinforcement Learning
    dataset:
      name: LunarLander-v3
      type: LunarLander-v3
    metrics:
    - type: mean_reward
      name: mean_reward
      value: 229.74 +/- 16.79
---
# PPO LunarLander-v3

Trained with Stable-Baselines3 on Gymnasium LunarLander-v3 using 16 environments.
Evaluation: 10 deterministic episodes, seed 12345.

## Evaluation

| Metric | Result |
| --- | --- |
| Mean episode reward | **229.74** |
| Standard deviation | 16.79 |
| Evaluation episodes | 10 |
| Environment | Gymnasium LunarLander-v3 |
| Evaluation seed | 12345 |

Full per-episode scores and lengths are available in [results.json](./resolve/main/results.json).

## Replay

<video controls src="https://huggingface.co/ZZW-Echo/ppo-LunarLander-v3/resolve/main/replay.mp4"></video>

## Usage

```python
from huggingface_hub import hf_hub_download
from stable_baselines3 import PPO
checkpoint = hf_hub_download(
    repo_id="ZZW-Echo/ppo-LunarLander-v3",
    filename="ppo-LunarLander-v3.zip",
)
model = PPO.load(checkpoint, device="cpu")
```

## Training

The training run requested 1,000,000 environment steps. Stable-Baselines3 completed
full rollouts for 1,015,808 actual steps using 16 subprocess environments and seed 42.
Policy: MlpPolicy; n_steps=1024; batch_size=64; n_epochs=4; gamma=0.999;
gae_lambda=0.98; ent_coef=0.01; learning_rate=0.0003.
Tested with Python 3.9, Stable-Baselines3 2.6.0, Gymnasium 1.1.1, and PyTorch 2.8.0.
The score above is a deterministic 10-episode evaluation of the final model in a
separate environment; it is not a guarantee for every random seed.
